# Cybersecurity Awareness Portal

A static, no-install website that teaches basic cyber safety.

## Features
- Common threats (phishing, malware, ransomware, social engineering, QR/payment fraud and more) as tap-to-expand cards
- Password strength checker (runs fully in the browser; nothing is stored or sent)
- 10 safety habits
- 7-question awareness quiz with explanations and a final score
- Incident response steps and Indian cyber crime helpline details

## How to run
Open `index.html` in any modern browser. No server or build step needed.

## Structure
```
cyber-awareness-portal/
├── index.html
├── css/style.css
└── js/
    ├── data.js   (threats, habits, quiz questions - edit content here)
    ├── main.js   (threat cards, habits, password checker)
    └── quiz.js   (quiz logic)
```

## Customising
- Change text, add threats or add quiz questions in `js/data.js`.
- Change colours at the top of `css/style.css` (the `:root` variables).
