// Content data for the Cybersecurity Awareness Portal.
// Edit this file to change threats, tips and quiz questions.

const THREATS = [
  {
    icon: "🎣",
    title: "Phishing",
    short: "Fake emails or messages that trick you into sharing passwords or OTPs.",
    signs: "Urgent tone, unknown sender, mismatched links, requests for credentials.",
    defence: "Never click unexpected links. Open the official site yourself and log in there."
  },
  {
    icon: "🦠",
    title: "Malware",
    short: "Malicious software such as viruses, spyware and trojans.",
    signs: "Slow device, strange pop-ups, unknown apps, files you did not download.",
    defence: "Install software only from trusted sources and keep antivirus and updates on."
  },
  {
    icon: "🔒",
    title: "Ransomware",
    short: "Malware that locks your files and demands payment to unlock them.",
    signs: "Files suddenly renamed or unopenable, a ransom note on screen.",
    defence: "Keep regular offline backups and avoid opening unknown attachments."
  },
  {
    icon: "🧠",
    title: "Social Engineering",
    short: "Manipulating people, rather than machines, into giving away access.",
    signs: "Pressure, fear, fake authority, or offers that seem too good to be true.",
    defence: "Pause and verify the person's identity through a separate, trusted channel."
  },
  {
    icon: "📶",
    title: "Public Wi-Fi Risks",
    short: "Open networks can let attackers snoop on traffic or imitate hotspots.",
    signs: "Hotspots with generic names, login pages asking for extra personal data.",
    defence: "Avoid banking on public Wi-Fi. Use mobile data or a trusted VPN."
  },
  {
    icon: "💳",
    title: "Online Payment Fraud",
    short: "Fake QR codes, fake refund calls and cloned shopping sites.",
    signs: "Requests to scan a QR code to receive money, or to share OTP or PIN.",
    defence: "You never need a PIN or OTP to receive money. Never share them."
  },
  {
    icon: "🎭",
    title: "Identity Theft",
    short: "Someone using your personal details to impersonate you.",
    signs: "Unknown transactions, accounts you did not open, unexpected bills.",
    defence: "Limit what you share publicly and monitor your accounts regularly."
  },
  {
    icon: "📱",
    title: "Fake Apps & SIM Swap",
    short: "Look-alike apps steal data; SIM swaps hijack your phone number.",
    signs: "Sudden loss of mobile signal, apps asking for needless permissions.",
    defence: "Check publisher and reviews before installing; contact your carrier at once if signal drops."
  }
];

const HABITS = [
  "<strong>Use a unique password</strong> for every account, ideally through a password manager.",
  "<strong>Turn on two-factor authentication</strong> wherever it is offered.",
  "<strong>Think before you click.</strong> Check the sender and hover over links first.",
  "<strong>Keep software updated</strong> on your phone, laptop and browser.",
  "<strong>Never share OTPs, PINs or CVV</strong> with anyone, including people claiming to be from a bank.",
  "<strong>Back up important files</strong> in more than one place.",
  "<strong>Lock your devices</strong> with a PIN, fingerprint or face unlock.",
  "<strong>Be careful what you post.</strong> Birthdays, addresses and ID photos help scammers.",
  "<strong>Download apps only</strong> from official stores and check permissions.",
  "<strong>Report and block</strong> suspicious messages instead of replying."
];

const QUIZ = [
  {
    q: "You receive an SMS saying your bank account will be blocked today unless you click a link. What should you do?",
    options: [
      "Click the link quickly to avoid being blocked",
      "Reply STOP to the sender",
      "Ignore the link and contact the bank using its official app or number",
      "Forward it to all your friends as a warning"
    ],
    answer: 2,
    explain: "Urgent threats are a classic phishing tactic. Always use an official channel you already trust."
  },
  {
    q: "Which of these is the strongest password?",
    options: ["password123", "Vishnu@2005", "Tr!ceBlue-Mango-Rain-47", "qwerty"],
    answer: 2,
    explain: "Long passphrases with mixed characters are far harder to guess than short or personal ones."
  },
  {
    q: "A stranger asks you to scan a QR code to receive money. What is true?",
    options: [
      "Scanning a QR code is how you receive money",
      "You never need to scan a QR code or enter a PIN to receive money",
      "It is safe if the amount is small",
      "It is safe if they sound polite"
    ],
    answer: 1,
    explain: "Scanning a QR code and entering your PIN sends money out. Receiving never needs your PIN."
  },
  {
    q: "What does two-factor authentication (2FA) add?",
    options: [
      "A second, different proof of identity besides your password",
      "A second password you must remember",
      "Faster logins",
      "Free antivirus"
    ],
    answer: 0,
    explain: "Even if your password leaks, an attacker still needs the second factor, such as an app code."
  },
  {
    q: "You find a USB drive in the college parking lot. What is the safest action?",
    options: [
      "Plug it in to find the owner",
      "Plug it into a lab computer instead of your own",
      "Hand it to the IT team without plugging it in",
      "Format it and keep it"
    ],
    answer: 2,
    explain: "Unknown USB devices can carry malware. Let trained staff handle them."
  },
  {
    q: "Which is the safest place to do online banking?",
    options: [
      "Free public Wi-Fi at a cafe",
      "Your own mobile data or trusted home network",
      "A shared computer at a browsing centre",
      "Any open hotspot with a strong signal"
    ],
    answer: 1,
    explain: "Public and shared networks or computers can expose your credentials."
  },
  {
    q: "Which number is the National Cyber Crime Helpline in India?",
    options: ["100", "1930", "108", "1098"],
    answer: 1,
    explain: "Dial 1930 for cyber fraud, especially financial fraud, as early as possible."
  }
];
