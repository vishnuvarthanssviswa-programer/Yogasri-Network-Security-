// Simple multiple-choice quiz with instant feedback and a final score.

(function () {
  const box = document.getElementById("quiz-box");
  let index = 0;
  let score = 0;

  function renderQuestion() {
    const item = QUIZ[index];
    box.innerHTML = "";

    const progress = document.createElement("p");
    progress.className = "quiz-progress";
    progress.textContent = "Question " + (index + 1) + " of " + QUIZ.length;
    box.appendChild(progress);

    const q = document.createElement("p");
    q.className = "quiz-q";
    q.textContent = item.q;
    box.appendChild(q);

    const buttons = [];
    item.options.forEach(function (text, i) {
      const b = document.createElement("button");
      b.className = "option";
      b.textContent = text;
      b.addEventListener("click", function () { choose(i, buttons, item); });
      buttons.push(b);
      box.appendChild(b);
    });
  }

  function choose(i, buttons, item) {
    buttons.forEach(function (b) { b.disabled = true; });
    if (i === item.answer) {
      score += 1;
      buttons[i].classList.add("correct");
    } else {
      buttons[i].classList.add("wrong");
      buttons[item.answer].classList.add("correct");
    }

    const explain = document.createElement("div");
    explain.className = "explain";
    explain.textContent = item.explain;
    box.appendChild(explain);

    const next = document.createElement("button");
    next.className = "btn";
    next.textContent = index === QUIZ.length - 1 ? "See my score" : "Next question";
    next.addEventListener("click", function () {
      index += 1;
      if (index < QUIZ.length) renderQuestion(); else renderResult();
    });
    box.appendChild(next);
  }

  function renderResult() {
    const pct = Math.round((score / QUIZ.length) * 100);
    let message;
    if (pct >= 85) message = "Excellent! You are cyber aware. Share what you know with friends.";
    else if (pct >= 60) message = "Good effort. Review the threats and tips above to close the gaps.";
    else message = "Keep learning. Read through the threats and habits sections and try again.";

    box.innerHTML =
      '<p class="quiz-progress">Quiz complete</p>' +
      '<p class="score">' + score + " / " + QUIZ.length + " (" + pct + "%)</p>" +
      "<p>" + message + "</p>";

    const again = document.createElement("button");
    again.className = "btn";
    again.textContent = "Try again";
    again.addEventListener("click", function () {
      index = 0;
      score = 0;
      renderQuestion();
    });
    box.appendChild(again);
  }

  renderQuestion();
})();
