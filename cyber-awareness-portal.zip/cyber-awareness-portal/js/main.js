// Renders threats and habits, and runs the password strength checker.

(function () {
  // ----- Threat cards -----
  const grid = document.getElementById("threat-grid");
  THREATS.forEach(function (t) {
    const card = document.createElement("article");
    card.className = "card threat";
    card.innerHTML =
      '<span class="icon">' + t.icon + "</span>" +
      "<h3>" + t.title + "</h3>" +
      "<p>" + t.short + "</p>" +
      '<div class="more">' +
      "<p><strong>Warning signs:</strong> " + t.signs + "</p>" +
      "<p><strong>How to stay safe:</strong> " + t.defence + "</p>" +
      "</div>" +
      '<p class="hint">Tap to learn more</p>';
    card.addEventListener("click", function () {
      card.classList.toggle("open");
    });
    grid.appendChild(card);
  });

  // ----- Habits list -----
  const habitList = document.getElementById("habit-list");
  HABITS.forEach(function (h) {
    const li = document.createElement("li");
    li.innerHTML = h;
    habitList.appendChild(li);
  });

  // ----- Password checker -----
  const pw = document.getElementById("pw");
  const showpw = document.getElementById("showpw");
  const bar = document.getElementById("meter-bar");
  const label = document.getElementById("pw-label");
  const tips = document.getElementById("pw-tips");

  const COMMON = ["password", "123456", "qwerty", "admin", "welcome", "letmein", "iloveyou", "abc123", "111111"];

  showpw.addEventListener("change", function () {
    pw.type = showpw.checked ? "text" : "password";
  });

  function evaluate(value) {
    const feedback = [];
    let score = 0;

    if (!value) return { score: 0, feedback: [] };

    if (value.length >= 8) score += 1; else feedback.push("Use at least 8 characters.");
    if (value.length >= 12) score += 1; else feedback.push("12 or more characters is much stronger.");
    if (/[a-z]/.test(value) && /[A-Z]/.test(value)) score += 1; else feedback.push("Mix uppercase and lowercase letters.");
    if (/\d/.test(value)) score += 1; else feedback.push("Add some numbers.");
    if (/[^A-Za-z0-9]/.test(value)) score += 1; else feedback.push("Add a symbol such as ! @ # or -.");

    const lower = value.toLowerCase();
    if (COMMON.some(function (c) { return lower.indexOf(c) !== -1; })) {
      score = Math.max(0, score - 2);
      feedback.push("Avoid common words and patterns like 'password' or '123456'.");
    }
    if (/(.)\1{2,}/.test(value)) {
      score = Math.max(0, score - 1);
      feedback.push("Avoid repeating the same character many times.");
    }
    return { score: score, feedback: feedback };
  }

  pw.addEventListener("input", function () {
    const result = evaluate(pw.value);
    const levels = [
      { text: "—", color: "#ef4444", width: 0 },
      { text: "Very weak", color: "#ef4444", width: 20 },
      { text: "Weak", color: "#f97316", width: 40 },
      { text: "Fair", color: "#f59e0b", width: 60 },
      { text: "Strong", color: "#84cc16", width: 80 },
      { text: "Very strong", color: "#22d3a6", width: 100 }
    ];
    const level = pw.value ? levels[Math.max(1, Math.min(result.score, 5))] : levels[0];
    bar.style.width = level.width + "%";
    bar.style.background = level.color;
    label.textContent = "Strength: " + level.text;

    tips.innerHTML = "";
    result.feedback.forEach(function (f) {
      const li = document.createElement("li");
      li.textContent = f;
      tips.appendChild(li);
    });
  });
})();
